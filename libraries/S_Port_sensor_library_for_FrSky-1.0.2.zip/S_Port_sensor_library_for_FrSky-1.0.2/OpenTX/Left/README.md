# Lua script to calculate the ml left from the provider value

Download the latest version: https://raw.githubusercontent.com/RealTadango/FrSky/master/Left/mlLeft.lua

Installation:
Copy mlLeft.lua to SCRIPTS\MIXER on the SD card and select the script in the Custom Scripts menu.

It has the folowing inputs:
 - Source: The source value for the consumed fuel
 - Tank_Size: The total size of the tank
 
Outputs:
 - Left: The tank size - the value
 
 