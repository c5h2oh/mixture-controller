# Lua RAS (SWR) mixer script

Download the latest version: https://raw.githubusercontent.com/RealTadango/FrSky/master/RAS/RAS.lua

Installation:
Copy RAS.lua to SCRIPTS\MIXER on the SD card and select the script in the Custom Scripts menu. Discover new sensors to enable the new virtual sensor. 

This script adds the RAS / SWR value as a telemetry sensor so it can be used within a Widget of logical switch. 