#Gauge widget for OpenTX

![Screenshot](screenshot.png)

Installation:
Download the latest version: https://raw.githubusercontent.com/RealTadango/FrSky/master/Gauge/Gauge.zip

Installation:
Unpack Gauge.zip to WIDGETS\Gauge on the SD card and you can select it as a Widget.

